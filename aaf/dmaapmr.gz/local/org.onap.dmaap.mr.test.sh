java -cp aaf-cadi-aaf-2.1.0-full.jar org.onap.aaf.cadi.aaf.TestConnectivity  cadi_prop_files=/opt/app/osaaf/client/etc/org.onap.dmaap.mr.props
# -Djavax.net.debug=ssl 
